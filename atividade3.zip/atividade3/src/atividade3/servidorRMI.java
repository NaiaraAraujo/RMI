package atividade3;
import java.rmi.*;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class servidorRMI {

		
		public static void main(String[] args) throws MalformedURLException {
			
			try {
				ICalculadora calc = new calculadoraIMPL();
				String objName = "rmi://localhost/Calc";
				
				System.out.println("registrando o objeto no RMIregistro");
				Registry registry = LocateRegistry.createRegistry(1313);
				Naming.rebind(objName, calc);
			
				System.out.println("Aguardando clientes");
			} catch (RemoteException e) {
				e.printStackTrace();
			}

		
	}

}
