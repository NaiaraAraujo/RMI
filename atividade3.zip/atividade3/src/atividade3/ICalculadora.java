package atividade3;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ICalculadora extends Remote {
	float adicao(float x, float y) throws RemoteException;

	float subtracao(float x, float y) throws RemoteException;

	float multiplicacao(float x, float y) throws RemoteException;

	float divisao(float x, float y) throws RemoteException;

	public int getValor() throws RemoteException;
 
	public int novoValor() throws RemoteException;

	

}
