package atividade3;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class clienteRMI {

		public static void main(String[] args) throws Exception {
			
			try {
				Registry registry = LocateRegistry.getRegistry(1313);
				ICalculadora stub = (ICalculadora) registry.lookup("getValor");
				int contador = stub.getValor();
				int novoValor = stub.novoValor();
				
			//servidorRMI stub = (servidorRMI) Naming.lookup("rmi://localhost:1313/servidorRMI");
			System.out.println("valor do contador: " + contador);
			System.out.println("novo contador: " + novoValor);
			
			}catch(RemoteException | NotBoundException e){
			
				e.printStackTrace();
			

		}
	}

}
