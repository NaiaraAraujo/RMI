package atividade3;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

	public class calculadoraIMPL extends UnicastRemoteObject implements ICalculadora {

		protected calculadoraIMPL() throws RemoteException {
			super();
		}

		private static final long serialVersionUID = 1L;

		@Override
		public float adicao(float x, float y) {
			return x + y;
		}

		@Override
		public float subtracao(float x, float y) throws RemoteException {
			return x - y;
		}

		@Override
		public float multiplicacao(float x, float y) throws RemoteException {
			return x * y;
		}

		@Override
		public float divisao(float x, float y) throws RemoteException {
			return x / y;
		}

		@Override
		public int getValor() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public int novoValor() {
			// TODO Auto-generated method stub
			return 0;
		}


	}



